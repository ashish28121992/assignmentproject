const AWS = require("aws-sdk");

// AWS_BUCKET_NAME = "mico-com"
// AWS_BUCKET_REGION = "ap-south-1"
// AWS_ACCESS_KEY="AKIAVUG2QJL56YXJV67L"
// AWS_SECRET_KEY="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"
const S3 = new AWS.S3({
  accessKeyId:"AKIAYNUAQPKBI4YMHQEV",
//   accessKeyId: process.env.AWS_ACCESS_KEY,
  secretAccessKey: "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",
//   secretAccessKey: process.env.AWS_SECRET_KEY,
  region: "ap-south-1",
});
let uploadS3 = async (fileContent, fileName) => {
  const params = {
    Bucket: "companytaskbucket",
    Key: fileName,
    Body: fileContent,
  };
  const uploadFile = await S3.upload(params).promise();

  return uploadFile;
};

module.exports = { uploadS3 };
