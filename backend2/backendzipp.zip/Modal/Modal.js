const mysql = require("mysql");
const con =  mysql.createConnection({
    host: "localhost",
    user:"root",
    password: "",
    database:"assignment"    
})

con.connect((err,result)=>{
    if (err) {
        console.log("database not connected", err.sqlMessage)
    }
    else(
        console.log("database connected")
    )
})
 module.exports ={con}